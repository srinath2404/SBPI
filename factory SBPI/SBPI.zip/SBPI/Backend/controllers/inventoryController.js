const Pipe = require("../models/Pipe");
const calculatePrice = require("../utils/priceCalculator");

// Add Pipe (Worker)
exports.addPipe = async (req, res) => {
    const { colorGrade, sizeType, length, weight } = req.body;
    try {
        const price = calculatePrice(colorGrade, sizeType, length, weight);
        const pipe = new Pipe({ colorGrade, sizeType, length, weight, worker: req.user.id, price });
        await pipe.save();
        res.status(201).json({ message: "Pipe added successfully", pipe });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// Get All Pipes (Manager)
exports.getAllPipes = async (req, res) => {
    try {
        const pipes = await Pipe.find().populate("worker", "name");
        res.json(pipes);
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};