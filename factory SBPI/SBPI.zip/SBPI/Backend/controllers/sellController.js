// controllers/sellController.js
const SellRequest = require("../models/SellRequest");

// Submit Sell Request (Worker)
exports.submitSellRequest = async (req, res) => {
    try {
        const { billNumber, pipes } = req.body;

        // Validate the number of pipes (min 1, max 50)
        if (!pipes || pipes.length < 1 || pipes.length > 50) {
            return res.status(400).json({ message: "A bill must contain between 1 and 50 pipes" });
        }

        // Create new sell request
        const sellRequest = new SellRequest({
            billNumber,
            pipes,
            worker: req.user.id, // Attach the worker's ID
        });

        await sellRequest.save();
        res.status(201).json({ message: "Sell request submitted successfully", sellRequest });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// Approve Sell Request (Manager)
exports.approveSellRequest = async (req, res) => {
    try {
        const sellRequest = await SellRequest.findByIdAndUpdate(
            req.params.id,
            { status: "approved" },
            { new: true }
        );
        res.json({ message: "Sell request approved", sellRequest });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// Decline Sell Request (Manager)
exports.declineSellRequest = async (req, res) => {
    try {
        const sellRequest = await SellRequest.findByIdAndUpdate(
            req.params.id,
            { status: "declined" },
            { new: true }
        );
        res.json({ message: "Sell request declined", sellRequest });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};