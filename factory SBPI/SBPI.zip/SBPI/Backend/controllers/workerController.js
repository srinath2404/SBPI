const User = require("../models/User");

// Create Worker (Manager Only)
exports.createWorker = async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const worker = await User.create({ name, email, password, role: "worker" });
        res.status(201).json({ message: "Worker created successfully", worker });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// Delete Worker (Manager Only)
exports.deleteWorker = async (req, res) => {
    try {
        await User.findByIdAndDelete(req.params.id);
        res.json({ message: "Worker deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// Get All Workers (Manager Only)
exports.getWorkers = async (req, res) => {
    try {
        const workers = await User.find({ role: "worker" }).select("-password");
        res.json(workers);
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};