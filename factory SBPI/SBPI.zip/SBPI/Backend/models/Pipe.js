const mongoose = require("mongoose");

const pipeSchema = new mongoose.Schema({
    colorGrade: { type: String, required: true },
    sizeType: { type: String, required: true },
    length: { type: Number, required: true },
    remainingLength: { type: Number, required: true },
    weight: { type: Number, required: true },
    serialNumber: { type: String, required: true, unique: true },
    price: { type: Number, required: true },
    worker: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    manufacturingDate: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Pipe", pipeSchema);