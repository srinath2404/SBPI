const mongoose = require("mongoose");

const sellRequestSchema = new mongoose.Schema({
    billNumber: { type: String, required: true, unique: true },
    pipes: [
        {
            serialNumber: { type: String, required: true },
            soldLength: { type: Number, required: true },
            price: { type: Number, required: true },
        },
    ],
    worker: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    status: { type: String, enum: ["pending", "approved", "declined"], default: "pending" },
    date: { type: Date, default: Date.now },
    discount: { type: Number, default: 0 }, // Discount in percentage
});

module.exports = mongoose.model("SellRequest", sellRequestSchema);