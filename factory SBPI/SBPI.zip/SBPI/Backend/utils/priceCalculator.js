const calculatePrice = (colorGrade, sizeType, length, weight) => {
    // Define base price per unit length for each color grade
    const basePrice = {
        green: 10,  // ₹10 per meter for green pipes
        yellow: 15, // ₹15 per meter for yellow pipes
        red: 20,    // ₹20 per meter for red pipes
    };

    // Define size multiplier for each pipe size type
    const sizeMultiplier = {
        "1 inch": 1.0,       // No additional charge for 1 inch
        "1-1.4 inch": 1.2,   // 20% additional charge for 1-1.4 inch
        "2 inch": 1.5,       // 50% additional charge for 2 inch
        "2-1.2 inch": 1.8,   // 80% additional charge for 2-1.2 inch
        "3 inch": 2.0,       // 100% additional charge for 3 inch
        "4 inch": 2.5,       // 150% additional charge for 4 inch
    };

    // Calculate total price
    const price = basePrice[colorGrade] * sizeMultiplier[sizeType] * length * weight;
    return price;
};

module.exports = calculatePrice;