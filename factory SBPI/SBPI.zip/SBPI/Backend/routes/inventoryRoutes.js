const express = require("express");
const { addPipe, getAllPipes } = require("../controllers/inventoryController");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/add", protect, addPipe);
router.get("/all", protect, getAllPipes);

module.exports = router;