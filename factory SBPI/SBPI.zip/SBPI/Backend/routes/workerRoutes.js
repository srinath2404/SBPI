const express = require("express");
const { createWorker, deleteWorker, getWorkers } = require("../controllers/workerController");
const { protect, managerOnly } = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/create", protect, managerOnly, createWorker);
router.delete("/delete/:id", protect, managerOnly, deleteWorker);
router.get("/all", protect, managerOnly, getWorkers);

module.exports = router;