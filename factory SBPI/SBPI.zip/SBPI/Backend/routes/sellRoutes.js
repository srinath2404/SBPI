// routes/sellRoutes.js
const express = require("express");
const { submitSellRequest, approveSellRequest, declineSellRequest } = require("../controllers/sellController");
const { protect, managerOnly } = require("../middleware/authMiddleware");

const router = express.Router();

// Ensure the controller functions are correctly imported
router.post("/submit", protect, submitSellRequest);
router.put("/approve/:id", protect, managerOnly, approveSellRequest);
router.put("/decline/:id", protect, managerOnly, declineSellRequest);

module.exports = router;