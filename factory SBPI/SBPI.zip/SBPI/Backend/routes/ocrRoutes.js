const express = require("express");
const { uploadImageAndExtractText, saveEditedData } = require("../controllers/ocrController");
const { protect, managerOnly } = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/upload", protect, managerOnly, uploadImageAndExtractText);
router.post("/save", protect, managerOnly, saveEditedData);

module.exports = router;